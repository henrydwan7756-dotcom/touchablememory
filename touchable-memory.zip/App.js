import React, { useEffect, useState } from 'react';
// truncated for brevity in this mock repo
export default function App(){return null;}